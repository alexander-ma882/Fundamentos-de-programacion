//Alexander Maldonado Alba

// funciones.cpp
#include <iostream>
#include "funciones.h"  // Incluir el archivo de cabecera

using namespace std;

// Definición de la función saludar
void saludar() {
    cout << "¡Hola desde el archivo funciones.cpp!" << endl;
}

// Definición de la función sumar
int sumar(int a, int b) {
    return a + b;
}